<?php
session_start();
require "db.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$categories = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Student Forum</title>
<script src="script.js"></script>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:"Segoe UI",sans-serif;
    background:linear-gradient(135deg,#0f172a,#1e293b);
    color:white;
}

/* HEADER */
.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:15px 40px;
    background:rgba(0,0,0,0.4);
    backdrop-filter:blur(10px);
}

/* LEFT SIDE */
.header-left{
    display:flex;
    align-items:center;
    gap:15px;
}

/* LOGO */
.logo{
    width:50px;
    height:50px;
    border-radius:50%;
    overflow:hidden;
    border:2px solid #3b82f6;
}

.logo img{
    width:100%;
    height:100%;
    object-fit:cover;
}

/* TITLE */
.header-left h2{
    font-weight:500;
}

/* LOGOUT */
.logout-btn{
    background:#ef4444;
    color:white;
    padding:8px 18px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    transition:0.3s;
}

.logout-btn:hover{
    background:#dc2626;
}

/* CONTAINER */
.container{
    width:90%;
    max-width:1100px;
    margin:40px auto;
}

/* SEARCH FILTER */
.search-filter{
    display:flex;
    gap:15px;
    margin-bottom:30px;
}

.search-filter input,
.search-filter select{
    padding:10px;
    border-radius:8px;
    border:none;
    width:100%;
}

/* CREATE POST */
.create-post{
    background:rgba(255,255,255,0.05);
    padding:25px;
    border-radius:15px;
    margin-bottom:40px;
    box-shadow:0 8px 20px rgba(0,0,0,0.3);
}

.create-post h3{
    margin-bottom:15px;
}

.create-post input,
.create-post textarea,
.create-post select{
    width:100%;
    padding:10px;
    margin-bottom:15px;
    border-radius:8px;
    border:none;
}

.create-post textarea{
    resize:none;
    height:100px;
}

.create-post button{
    background:#3b82f6;
    color:white;
    padding:10px 20px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    transition:0.3s;
}

.create-post button:hover{
    background:#2563eb;
}

/* POSTS */
.post{
    background:rgba(255,255,255,0.05);
    padding:20px;
    border-radius:15px;
    margin-bottom:20px;
    box-shadow:0 5px 15px rgba(0,0,0,0.3);
}

@media(max-width:768px){
    .search-filter{
        flex-direction:column;
    }
}

</style>
</head>

<body onload="loadPosts()">

<!-- HEADER -->
<div class="header">

    <div class="header-left">
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
        <h2>Welcome to our Forum</h2>
    </div>

    <a href="login.php">
        <button class="logout-btn">Logout</button>
    </a>

</div>

<div class="container">

<!-- SEARCH & FILTER -->
<div class="search-filter">
    <input type="text" id="search" placeholder="Search..." onkeyup="loadPosts()">
    
    <select id="filter" onchange="loadPosts()">
        <option value="">All Categories</option>
        <?php while($cat = $categories->fetch_assoc()): ?>
        <option value="<?php echo $cat['id']; ?>">
            <?php echo $cat['category_name']; ?>
        </option>
        <?php endwhile; ?>
    </select>
</div>

<!-- CREATE POST -->
<div class="create-post">
    <h3>Create Post</h3>

    <form id="postForm">
        <input type="text" name="title" placeholder="Title" required>

        <textarea name="content" placeholder="Write your content..." required></textarea>

        <select name="category" required>
            <?php
            $categories2 = $conn->query("SELECT * FROM categories");
            while($cat = $categories2->fetch_assoc()):
            ?>
            <option value="<?php echo $cat['id']; ?>">
                <?php echo $cat['category_name']; ?>
            </option>
            <?php endwhile; ?>
        </select>

        <button type="submit">Post</button>
    </form>
</div>

<hr style="opacity:0.2; margin-bottom:30px;">

<div id="posts"></div>

</div>
<script src="script.js"></script>

</body>
</html>

