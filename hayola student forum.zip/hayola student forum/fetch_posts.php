<?php
session_start();
require "db.php";

$search = $_POST["search"];
$filter = $_POST["filter"];

$sql = "SELECT posts.*, users.fullname, categories.category_name 
        FROM posts
        JOIN users ON posts.user_id = users.id
        JOIN categories ON posts.category_id = categories.id
        WHERE 1";

if(!empty($search)){
    $sql .= " AND posts.title LIKE '%$search%'";
}

if(!empty($filter)){
    $sql .= " AND posts.category_id = '$filter'";
}

$sql .= " ORDER BY posts.created_at DESC";

$result = $conn->query($sql);

while($row = $result->fetch_assoc()){
    echo "<div class='post'>";
    echo "<h3>".$row['title']."</h3>";
    echo "<small>By ".$row['fullname']." • ".$row['category_name']."</small>";
    echo "<p>".$row['content']."</p>";
    echo "</div>";
}
?>
ss