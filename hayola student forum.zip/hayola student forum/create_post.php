<?php
session_start();
require "db.php";

if(isset($_SESSION["user_id"])){

    $title = $_POST["title"];
    $content = $_POST["content"];
    $category = $_POST["category"];
    $user_id = $_SESSION["user_id"];

    $stmt = $conn->prepare("INSERT INTO posts (user_id, category_id, title, content) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiss", $user_id, $category, $title, $content);
    $stmt->execute();
}
?>
