<?php
session_start();
require "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $fullname = trim($_POST["fullname"]);
    $email = trim($_POST["email"]);
    $username = trim($_POST["username"]);
    $passwordRaw = $_POST["password"];

    // VALIDATION
    if(empty($fullname) || empty($email) || empty($username) || empty($passwordRaw)){
        $error = "All fields are required.";
    }
    elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $error = "Invalid email format.";
    }
    elseif(strlen($username) < 4){
        $error = "Username must be at least 4 characters.";
    }
    elseif(strlen($passwordRaw) < 6){
        $error = "Password must be at least 6 characters.";
    }
    elseif(!preg_match("/[A-Z]/",$passwordRaw) ||
           !preg_match("/[a-z]/",$passwordRaw) ||
           !preg_match("/[0-9]/",$passwordRaw)){
        $error = "Password must contain uppercase, lowercase and number.";
    }
    else{

        $password = password_hash($passwordRaw, PASSWORD_DEFAULT);

        $check = $conn->prepare("SELECT id FROM users WHERE email=? OR username=?");
        $check->bind_param("ss", $email, $username);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = "Email or Username already exists";
        } else {

            $stmt = $conn->prepare("INSERT INTO users (fullname,email,username,password) VALUES (?,?,?,?)");
            $stmt->bind_param("ssss", $fullname, $email, $username, $password);

            if ($stmt->execute()) {
                $_SESSION["success"] = "Registration successful. Please login.";
                header("Location: login.php");
                exit();
            } else {
                $error = "Registration failed";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Student Forum - Register</title>
<link rel="stylesheet" href="auth.css">
</head>
<body>

<div class="auth-card">

    <div class="logo-circle">
        <img src="logo.png" alt="Student Forum Logo">
    </div>

    <h1>Create Account</h1>
    <p class="subtitle">Join the Student Forum</p>

    <?php
    if(isset($error)){
        echo "<p class='error-msg'>".$error."</p>";
    }
    ?>

    <form action="register.php" method="POST" id="registerForm">

        <div class="input-group">
            <label>Full Name</label>
            <input type="text" name="fullname" id="fullname" required>
        </div>

        <div class="input-group">
            <label>Email</label>
            <input type="email" name="email" id="email" required>
        </div>

        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" id="username" required>
        </div>

        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password" id="password" required>
        </div>

        <button type="submit" class="btn">Register</button>

    </form>

    <div class="switch">
        Already have an account? <a href="login.php">Login</a>
    </div>

</div>

<script src="script.js"></script>
</body>
</html>

