<?php
session_start();
require "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    if(empty($username) || empty($password)){
        $error = "All fields are required.";
    }
    else{

        $stmt = $conn->prepare("SELECT id,password,fullname FROM users WHERE username=?");
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $result = $stmt->get_result();

        if($result->num_rows == 1){
            $user = $result->fetch_assoc();

            if(password_verify($password,$user["password"])){

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["username"] = $user["fullname"];

                header("Location: home.php");
                exit();
            } else {
                $error = "Incorrect password.";
            }
        } else {
            $error = "Username not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Forum | Login</title>
<link rel="stylesheet" href="auth.css">
</head>

<body>

<div class="auth-card">

    <div class="logo-circle">
        <img src="logo.png" alt="Student Forum Logo">
    </div>

    <h1>Welcome Back</h1>
    <p class="subtitle">Login to continue</p>

    <?php
    if(isset($_SESSION["success"])){
        echo "<p class='success-msg'>".$_SESSION["success"]."</p>";
        unset($_SESSION["success"]);
    }

    if(isset($error)){
        echo "<p class='error-msg'>".$error."</p>";
    }
    ?>

    <form action="login.php" method="POST" id="loginForm">

        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" id="loginUsername" required>
        </div>

        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password" id="loginPassword" required>
        </div>

        <button type="submit" class="btn">Login</button>

    </form>

    <p class="switch">
        Don't have an account?
        <a href="register.php">Register</a>
    </p>

</div>

<script src="script.js"></script>
</body>
</html>

